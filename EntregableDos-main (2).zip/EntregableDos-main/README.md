# EntregableDos

En este entregable se constuirán varias funciones que se pueden resolver con lo visto en clase.
